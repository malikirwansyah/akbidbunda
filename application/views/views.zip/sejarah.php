
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
      <div class="box-header well">
        <h2>Sejarah berdirinya AKBID keluarga bunda jambi</h2>
      </div>
      <div class="box-content row">
        <div class="col-md-12">
       <p class="text-justify">
         Akademi Kebidanan (AKBID) Keluarga Bunda Jambi merupakan institusi perguruan tinggi yang berada dibawah naungan Yayasan Keluarga Bunda Jambi. Berdirinya institusi didasari keinginan untuk berperan dalam pembangunan nasional melalui pendidikan dan adanya pemikiran akan kebutuhan tenaga kesehatan di Indonesia yang masih cukup besar serta tingginya minat masyarakat di Propinsi Jambi untuk menjadi tenaga kesehatan khususnya bidan. Akbid Keluarga Bunda Jambi diharapkan dapat memenuhi kebutuhan akan Ahli Madya Kebidanan yang profesional,intelektual dan komunikatif.
      </p>
<p class="text-justify">
  Akbid Keluarga Bunda Jambi didirikan pada tahun 2007 berdasarkan Surat Keputusan Departemen Pendidikn Nasional Direktorat Jenderal Pendidikan Tinggi Nomor: 192/D/O/2007 tanggal 1 Oktober 2007, atas rekomendasi dari Departemen Kesehatan Republik Indonesia Badan Pengembangan Dan Pemberdayaan Sumber Daya Manusia Kesehatan Nomor: HK.03.2.4..1.03522 tanggal 02 Agustus 2007, dan Pemerintah Propinsi Jambi Dinas Kesehatan Nomor: 420/1120/Dinkes/2007 tanggal 03 Juni 2007. 
</p>
<p class="text-justify">
Akademi Kebidanan Keluarga Bunda Jambi telah terakreditasi oleh Badan Akreditasi Nasional Perguruan Tinggi (BAN-PT) Nomor: 040/SK/BAN-PT/Ak-XII/Dpl-III/II/2013 pada tanggal 07 Februari 2013.
</p>
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
