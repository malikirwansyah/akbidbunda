
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
     <div class="box-header well">
        <h2>Visi Dan Misi AKBID keluarga bunda Jambi </h2>
      </div>
      <div class="box-content row">
        <div class="col-md-12">
        <h4><font color="black"><p class="text-center"><b>Visi</b></p></font></h4>
<p class="text-justify">
  Akademi Kebidanan Keluarga Bunda Jambi tahun 2016 menghasilkan Ahli Madya Kebidanan yang berkualitas, berdaya saling global dan bertaqwa kepada Tuhan Yang Maha Esa.
</p>

<h4><font color="black"><p class="text-center"><b>Misi</b></p></font></h4>
<p class="text-justify">

  <b>Pendidikan:</b><br/>
  <ul>1.  Melaksanakan pembelajaran berbasis kompetensi</ul>
  <ul>2.  Menyiapkan prasarana dan sarana untuk menunjang proses pembelajaran.</ul>

  <b>Penelitian:</b><br/>
  <ul>1.  Melaksanakan penelitian dibidang kebidanan.</ul>
  <ul>2.  Mendorong dosen dan mahasiswa melakukan pengembangan ilmu melalui penelitian.</ul>
  <ul>3.  Menyediakan sarana untuk pelaksanaan penelitian.</ul>

  <b>Pengabdian Masyarakat:</b><br/>
  <ul>1.  Mengembangkan kerjasama lintas sektoral</ul>
  <ul>2.  Melaksanakan pelayanan dan pengabdian masyarakat</ul>


</p>


          
       
            
        
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
