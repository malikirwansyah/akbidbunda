
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
      <div class="box-header well">
        <h2>Struktur Organisasi AKBID keluarga bunda jambi</h2>
      </div>
      <div class="box-content row">
        <div class="col-md-12">
       
            <img class="img-responsive" src="<?php echo base_url(); ?>asset/bootstrap/img/struk.png">
        
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
