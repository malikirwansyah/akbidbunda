
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
      <div class="box-content row">
        <div class="col-md-12">
        <h4><font color="red"><p style="margin-left:5%;">Mengapa anda harus memilih AKBID keluarga bunda jambi ..??</p></font></h4>
<p style="margin-left:10%;">• Kami memiiliki dosen atau tenaga pengajar yang profesional di bidangnya</p> 
<p style="margin-left:10%;">• Disiplin waktu</p>
<p style="margin-left:10%;">• Sarana dan prasarana yang lengkap</p>
<p style="margin-left:10%;">• Memiliki klinik kesehatan 24 jam</p>

           
       
            
        
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
