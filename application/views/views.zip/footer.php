
  <hr>
  <footer class="row">
    <p class="col-md-12 text-center">&copy; <a href="#">Akademik Kebidanan Keluarga Bunda Jambi</a> 2015 - 2016</p>
    <p class="col-md-12 text-center">Jl. Sultan Hasanuddin Rt 43 Kelurahan Talang Bakung Kecamatan Jambi Selatan Kota Jambi</p>
  	<p class="col-md-12 text-center">Telp. 0741 570884, Fax 0741 570884</p>
  </footer>
</div> <!-- /ch-container -->
<script src="<?php echo base_url(); ?>asset/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.cookie.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/moment.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/fullcalendar.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/chosen.jquery.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.colorbox-min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.noty.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/responsive-tables.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/bootstrap-tour.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.raty.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.iphone.toggle.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.autogrow-textarea.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.uploadify-3.1.min.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.history.js"></script>
<script src="<?php echo base_url(); ?>asset/bootstrap/js/charisma.js"></script>

  </body>
</html>
