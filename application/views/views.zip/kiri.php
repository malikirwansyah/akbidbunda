<div class="col-sm-2 col-lg-2">
      <div class="sidebar-nav">
        <div class="nav-canvas">
          <div class="nav-sm nav nav-stacked">

          </div>
          <ul class="nav nav-pills nav-stacked main-menu">
            <li class="nav-header">Informasi</li>
            <li><a href="<?php echo base_url(); ?>index.php/app/kenapa/"><i class="glyphicon glyphicon-question-sign"></i><span> Mengapa Akbid Bunda </span></a></li>
            <li><a href="<?php echo base_url(); ?>index.php/app/informasi_pmb" ><i class="glyphicon glyphicon-eye-open"></i><span> Informasi Pendaftaran</span></a></li>
           <!--- <li><a href="<?php echo base_url(); ?>index.php/app/informasi_nilai/"><i class="glyphicon glyphicon-book"></i><span> Informasi Nilai</span></a></li>-->
           <!--- <li><a href="<?php //echo base_url(); ?>index.php/app/calender_akademik/"><i class="glyphicon glyphicon-calendar"></i><span> Calender Akademik</span></a></li> -->
            <li class="accordion">
                            <a href="#"><i class="glyphicon glyphicon-plus"></i><span> Informasi Nilai</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="<?php echo base_url(); ?>index.php/app/login_mhs/">Login Mahasiswa</a></li>
                            </ul>
                        </li>
            <li><a href="<?php echo base_url(); ?>index.php/app/target" ><i class="glyphicon glyphicon-user"></i><span> Login Administrator</span></a></li>            
           
         </ul>
        </div>
      </div>
</div>