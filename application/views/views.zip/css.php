 <link href="<?php echo base_url(); ?>asset/bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/charisma-app.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/fullcalendar.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/fullcalendar.print.css" rel='stylesheet' media='print'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/chosen.min.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/colorbox.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/responsive-tables.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/bootstrap-tour.min.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/jquery.noty.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/noty_theme_default.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/elfinder.min.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/elfinder.theme.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/jquery.iphone.toggle.css" rel='stylesheet'>
        <link href="<?php echo base_url(); ?>asset/bootstrap/css/uploadify.css" rel='stylesheet'>	
        <!-- jQuery -->
         <script src="<?php echo base_url(); ?>asset/bootstrap/js/jquery.min.js"></script>