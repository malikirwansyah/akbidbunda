
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
     
       <div class="box-header well">
        <h2>Sarana dan prasarana AKBID keluarga bunda jambi </h2>
      </div>
      <div class="box-content row">
        <div class="col-md-12">
       
            <p class="text-justify">
              Kampus Akbid Keluarga Bunda Jambi didirikan diatas lahan milik sendiri dengan luas lebih kurang 8000 meter persegi, dengan fasilitas:
            </p>
            <p>
                          
            <ul>• Klinik Keluarga Bunda Jambi yang melayani rawt inap dan rawat jalan</ul>
            <ul>• Ruang Kuliah nyaman</ul>
            <ul>• Ruang Laboratorium Kebidanan</ul>
            <ul>• Ruang Laboratorium Komputer dan Internet</ul>
            <ul>• Ruang Laboratorium Bahasa</ul>
            <ul>• Ruang Perpustakaan</ul>
            <ul>• Aula bisa menampung ± 300 orang</ul>
            <ul>• Asrama</ul>
            <ul>• Ruang Makan</ul>
            <ul>• Keamanan 24 Jam</ul>
            <ul>• Lapangan Olah Raga</ul>
            <ul>• Ruang Tamu</ul>
            <ul>• Lapangan Parkir</ul>
            <ul>• Kantin</ul>
            

            </p>
        <img src="<?php echo base_url(); ?>asset/bootstrap/img/fasi.jpg" class="img-responsive">
            
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
