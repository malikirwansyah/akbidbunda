
  <div class="row">

<?php 
  $this->load->view('kiri');
 ?>

    <div id="content" class="col-lg-10 col-sm-10">
      <!-- content starts -->
      <div>
 
</div>

<div class="row">

  <div class="col-md-9">
    <div class="box-inner">
     <div class="box-header well">
        <h2>Sambutan Kepala SD Negeri 79 </h2>
      </div>
      <div class="box-content row">
        <div class="col-md-12">
        <h4><font color="red"><p class="text-center">Selamat Datang di Website SD NEGERI 79/IV Kota Jambi</p></font></h4>
<p class="text-justify" style="margin:1%;">
Puji syukur kami panjatkan ke hadirat Tuhan Yang Maha Esa atas karunia dan hidayah-Nya, sehingga  kita semua 
dapat membaktikan segala hal yang kita miliki untuk kemajuan dunia pendidikan. Apapun bentuk dan  sumbangsih 
yang kita berikan, jika dilandasi niat yang tulus tanpa memandang imbalan apapun akan menghasilkan mahakarya 
yang agung untuk bekal kita dan generasi setelah kita.

Pendidikan adalah harga mati untuk menjadi pondasi bangsa dan negara dalam  menghadapi  perkembangan  zaman. 
Hal ini seiring dengan penguasaan teknologi untuk dimanfaatkan sebaik  mungkin,  sehingga  menciptakan iklim 
kondusif dalam ranah keilmuan. Dengan konsep yang kontekstual dan efektif, kami mengejewantahkan nilai-nilai 
pendidikan yang tertuang dalam visi misi SD NEGERI 79/IV Kota Jambi, sebagai panduan hukum dalam menjabarkan
tujuan hakiki pendidikan.

Dalam sebuah sistem ketata kelolaan  Sekolah  Berbasis  Manajemen,  kami berusaha terus meningkatkan kinerja 
dan  profesionalisme  demi  terwujudnya  pelayanan  prima  dalam  cakupan  Lembaga  Pendidikan  terutama  di 
SD NEGERI 79/IV Kota Jambi. Kami  sudah  mulai  menerapkan  sistem Teknologi Komputerisasi agar transparansi 
pengelolaan pendidikan terjaga optimalisasinya.

Sebuah sistem akan bermanfaat dan berdaya guna tinggi jika  didukung  dan direalisasikan oleh semua komponen 
yang berkompeten di SD NEGERI 79/IV Kota Jambi baik sistem manajerial, akademik, pelayanan publik, prestasi,
moralitas  dan  semua  hal  yang  berinteraksi  di dalamnya. Alhamdulilah peningkatan tersebut dapat dilihat 
dari  data-data  kepegawaian  dan  karya-karya nyata yang telah dihasilkan walaupun masih ada kelemahan yang 
terus kami treatment dengan menyeimbangkan hasil kinerja dan prize yang diberikan. Mudah-mudahan  semua yang 
kita berikan untuk kemajuan dan keajegan nilai-nilai pendidikan dapat terus meningkat.

Secara pribadi saya mohon maaf, jika  pemenuhan  tuntutan dan kinerja yang saya lakukan masih ada kelemahan. 
Oleh karena itu, bantuan dan kerjasama dari berbagai pihak  untuk  optimalisasi mutu dan kualitas pendidikan 
sangat  saya  harapkan.  Mudah-mudahan  dalam tiap langkah dan nafas kita menciptakan nilai jual yang tinggi 
bagi keilmuan dan nilai hakiki di hadapan Tuhan Yang Maha Esa.
Demikian sambutan ini saya sampaikan, ditutup dengan pesan moral dan keilmuan bagi kita semua.

        </p>
       
            
        
        </div>
      </div>
    </div>
  </div>

<?php 
  $this->load->view('kanan');
 ?>
</div>

  

  <!-- content ends -->
  </div><!--/#content.col-md-0-->
</div><!--/fluid-row-->
